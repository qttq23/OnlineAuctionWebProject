# 1753102 - Bui Quang Thang
(1 member group)

# Online Auction Web Project

# requirement
- up to date browser (Google chrome is suggested, others are not tested)

# to run:
- go to 'src' folder and double click to 'homepage.html'

or
- open command prompt in this folder 'webProject' and type:
start src/homepage.html

# notes: upload images just work if choose images on folder 'src/images/'

# folders:
docs: documents
src: source code
revision: all versions of this web app.
screenshots: some images of web screen

# github:
https://github.com/qttq23/OnlineAuctionWebProject.git

